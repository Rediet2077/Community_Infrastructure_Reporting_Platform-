from django.apps import AppConfig


class CollaborationsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'apps.collaborations'
    verbose_name = 'Inter-Departmental Collaborations'