from django.contrib.gis.geos import Point
from rest_framework import serializers
from utils.enums import LocationSource
from apps.locations.models import Location
from .models import Asset, AssetType


class AssetTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = AssetType
        fields = ['id', 'name', 'code', 'description', 'requires_location', 'is_active']


class AssetLocationInputSerializer(serializers.Serializer):
    """Validates the incoming GPS coordinates for the asset location."""
    lat = serializers.FloatField(required=True)
    lng = serializers.FloatField(required=True)
    address = serializers.CharField(required=False, allow_blank=True, default='')
    landmark = serializers.CharField(required=False, allow_blank=True, default='')


class AssetSerializer(serializers.ModelSerializer):
    """Read serializer for Asset data."""
    asset_type_name = serializers.ReadOnlyField(source='asset_type.name')
    department_name = serializers.ReadOnlyField(source='department.name')
    latitude = serializers.FloatField(source='location.latitude', read_only=True)
    longitude = serializers.FloatField(source='location.longitude', read_only=True)

    class Meta:
        model = Asset
        fields = [
            'id', 'asset_code', 'name', 'description',
            'asset_type', 'asset_type_name', 'department', 'department_name',
            'location', 'latitude', 'longitude',
            'status', 'condition', 'installation_date',
            'extra_data', 'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']


class AssetRegistrationSerializer(serializers.Serializer):
    """Write serializer for registering a new infrastructure asset."""
    asset_code = serializers.CharField(max_length=100)
    name = serializers.CharField(max_length=200)
    description = serializers.CharField(required=False, allow_blank=True)
    asset_type_id = serializers.UUIDField(required=True)
    condition = serializers.CharField(max_length=20)
    status = serializers.CharField(max_length=20, required=False, default='ACTIVE')
    installation_date = serializers.DateField(required=False, allow_null=True)
    extra_data = serializers.DictField(required=False, default=dict)
    location = AssetLocationInputSerializer(required=True)

    def validate_asset_code(self, value):
        if Asset.objects.filter(asset_code=value).exists():
            raise serializers.ValidationError("An asset with this code already exists.")
        return value

    def validate_asset_type_id(self, value):
        try:
            return AssetType.objects.get(id=value, is_active=True)
        except AssetType.DoesNotExist:
            raise serializers.ValidationError("Asset type not found or is inactive.")

    def validate_condition(self, value):
        from utils.enums import AssetCondition
        valid = [c[0] for c in AssetCondition.choices]
        if value.upper() not in valid:
            raise serializers.ValidationError(f"Invalid condition. Choose from: {valid}")
        return value.upper()

    def validate_status(self, value):
        from utils.enums import AssetStatus
        valid = [s[0] for s in AssetStatus.choices]
        if value.upper() not in valid:
            raise serializers.ValidationError(f"Invalid status. Choose from: {valid}")
        return value.upper()