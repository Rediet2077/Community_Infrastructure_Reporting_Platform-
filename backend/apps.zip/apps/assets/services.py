from django.db import transaction
from django.contrib.gis.geos import Point
from apps.assets.models import Asset, AssetType
from apps.locations.models import Location
from apps.departments.models import Department
from rest_framework.exceptions import NotFound, ValidationError
from utils.enums import LocationSource

@transaction.atomic
def register_infrastructure_asset(user, validated_data: dict) -> Asset:
    """
    Core business logic for registering a physical infrastructure asset.
    """
    # 1. Enforce Role Accountability
    # Ensure the user actually manages a department
    try:
        department = user.managed_department
    except Department.DoesNotExist:
        raise ValidationError("Only users assigned to a department can register assets.")

    # 2. Extract Nested Data
    location_data = validated_data.pop('location')
    asset_type = validated_data.pop('asset_type_id')  # Already resolved to instance by serializer

    geom_point = Point(
        float(location_data['lng']),
        float(location_data['lat']),
        srid=4326
    )

    
    location = Location.objects.create(
        geom=geom_point,
        address=location_data.get('address'),
        landmark=location_data.get('landmark'),
        source=LocationSource.ASSET
    )

    # 4. Create the Asset Entity
    asset = Asset.objects.create(
        department=department,
        registered_by=user,
        location=location,
        asset_type=asset_type,
        **validated_data
    )

    return asset