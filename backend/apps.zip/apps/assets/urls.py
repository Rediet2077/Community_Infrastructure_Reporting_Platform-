from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import AssetRegistrationView, AssetViewSet, AssetTypeViewSet

router = DefaultRouter()
router.register(r'', AssetViewSet, basename='asset')
router.register(r'types', AssetTypeViewSet, basename='assettype')

urlpatterns = [
    path('register/', AssetRegistrationView.as_view(), name='asset-register'),
    path('', include(router.urls)),
]