from rest_framework import views, viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from django_filters.rest_framework import DjangoFilterBackend
from utils.permissions import IsAdminOrDepartmentAdmin, IsSystemAdmin
from utils.responses import success_response
from utils.audit import record_audit_log

from .models import Asset, AssetType
from .serializers import AssetRegistrationSerializer, AssetSerializer, AssetTypeSerializer
from .services import register_infrastructure_asset


class AssetTypeViewSet(viewsets.ModelViewSet):
    """
    GET /api/v1/assets/types/
    List asset types for category selection during asset registration.
    Full CRUD for admins.
    """
    queryset = AssetType.objects.filter(is_active=True).order_by('name')
    serializer_class = AssetTypeSerializer
    permission_classes = [IsAuthenticated]

    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [IsSystemAdmin()]
        return super().get_permissions()

class AssetViewSet(viewsets.ModelViewSet):
    """
    Full CRUD for infrastructure assets.
    - Admins: Full access
    - Department Admins: See and manage their department's assets
    - Citizens: Read-only (for report linking)
    """
    queryset = Asset.objects.select_related(
        'asset_type', 'department', 'location', 'registered_by'
    ).order_by('-created_at')
    serializer_class = AssetSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['status', 'condition', 'department', 'asset_type']
    search_fields = ['asset_code', 'name']
    ordering_fields = ['created_at', 'name', 'status']

    def get_queryset(self):
        user = self.request.user
        if user.is_staff or user.role == 'SYSTEM_ADMIN':
            return self.queryset
        dept = getattr(user, 'managed_department', None)
        if dept:
            return self.queryset.filter(department=dept)
        # Citizens see all active assets for report linking
        return self.queryset.filter(status='ACTIVE')

    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy', 'deactivate']:
            return [IsAuthenticated(), IsAdminOrDepartmentAdmin()]
        return [IsAuthenticated()]

    @action(detail=True, methods=['post'], url_path='deactivate')
    def deactivate(self, request, pk=None):
        asset = self.get_object()
        asset.status = 'INACTIVE'
        asset.save(update_fields=['status', 'updated_at'])
        return success_response(message="Asset deactivated.")

    @action(detail=True, methods=['get'], url_path='reports')
    def asset_reports(self, request, pk=None):
        from apps.reports.models import Report
        from apps.reports.serializers import ReportSerializer
        
        asset = self.get_object()
        reports = Report.objects.filter(asset=asset).order_by('-created_at')
        return success_response(data=ReportSerializer(reports, many=True).data)

    @action(detail=True, methods=['get'], url_path='tasks')
    def asset_tasks(self, request, pk=None):
        from apps.tasks.models import Task
        from apps.tasks.serializers import TaskSerializer
        
        asset = self.get_object()
        tasks = Task.objects.filter(asset=asset).order_by('-created_at')
        return success_response(data=TaskSerializer(tasks, many=True).data)

    @action(detail=True, methods=['get'], url_path='statistics')
    def asset_statistics(self, request, pk=None):
        from apps.reports.models import Report
        from apps.tasks.models import Task
        
        asset = self.get_object()
        report_count = Report.objects.filter(asset=asset).count()
        task_count = Task.objects.filter(asset=asset).count()
        
        stats = {
            "total_reports": report_count,
            "total_tasks": task_count
        }
        return success_response(data=stats)

class AssetRegistrationView(views.APIView):
    """
    POST /api/v1/assets/register/
    Department Admin registers a new physical infrastructure asset.
    Handles location creation and full business logic via the service layer.
    """
    permission_classes = [IsAuthenticated, IsAdminOrDepartmentAdmin]

    def post(self, request):
        serializer = AssetRegistrationSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        asset = register_infrastructure_asset(
            user=request.user,
            validated_data=serializer.validated_data
        )

        record_audit_log(
            action="ASSET_REGISTERED",
            entity_type="Asset",
            entity_id=asset.id,
            actor=request.user,
            request=request,
            new_values={"asset_code": asset.asset_code, "name": asset.name},
        )

        return success_response(
            data=AssetSerializer(asset).data,
            message="Asset registered successfully.",
            status_code=status.HTTP_201_CREATED,
        )