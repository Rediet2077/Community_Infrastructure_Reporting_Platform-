from rest_framework import serializers
from .models import Category

class CategorySerializer(serializers.ModelSerializer):
    subcategories = serializers.SerializerMethodField()

    class Meta:
        model = Category
        fields = ['id', 'name', 'code', 'description', 'parent', 'subcategories', 'is_active', 'created_at', 'updated_at']

    def get_subcategories(self, obj):
        # Prevent infinite recursion if tree is deep, but standard is 1-2 levels
        if obj.subcategories.exists():
            return CategorySerializer(obj.subcategories.all(), many=True).data
        return []
