from rest_framework import viewsets
from rest_framework.permissions import IsAuthenticated
from .models import Category
from .serializers import CategorySerializer

from utils.permissions import IsSystemAdmin

class CategoryViewSet(viewsets.ModelViewSet):
    """
    API ViewSet for managing categories. Full CRUD for admins.
    """
    queryset = Category.objects.filter(is_active=True).select_related('parent')
    serializer_class = CategorySerializer
    permission_classes = [IsAuthenticated]
    
    def get_permissions(self):
        if self.action in ['create', 'update', 'partial_update', 'destroy']:
            return [IsSystemAdmin()]
        return super().get_permissions()
    
    def get_queryset(self):
        """
        By default, only return root categories.
        Subcategories are nested via the serializer.
        """
        return self.queryset.filter(parent__isnull=True)
