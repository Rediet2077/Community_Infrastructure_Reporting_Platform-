from django.urls import path
from .views import (
    DashboardSummaryView,
    ReportStatisticsView,
    TaskStatisticsView,
    AssetStatisticsView,
    PriorityStatisticsView,
    RecentReportsView,
    RecentTasksView,
    RecentNotificationsView,
    OverdueTasksView
)

urlpatterns = [
    path('summary/', DashboardSummaryView.as_view(), name='dashboard_summary'),
    path('report-statistics/', ReportStatisticsView.as_view(), name='dashboard_report_statistics'),
    path('task-statistics/', TaskStatisticsView.as_view(), name='dashboard_task_statistics'),
    path('asset-statistics/', AssetStatisticsView.as_view(), name='dashboard_asset_statistics'),
    path('priority-statistics/', PriorityStatisticsView.as_view(), name='dashboard_priority_statistics'),
    path('recent-reports/', RecentReportsView.as_view(), name='dashboard_recent_reports'),
    path('recent-tasks/', RecentTasksView.as_view(), name='dashboard_recent_tasks'),
    path('recent-notifications/', RecentNotificationsView.as_view(), name='dashboard_recent_notifications'),
    path('overdue-tasks/', OverdueTasksView.as_view(), name='dashboard_overdue_tasks'),
]
