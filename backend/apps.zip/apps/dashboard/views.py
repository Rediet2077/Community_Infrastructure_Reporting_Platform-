from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from django.db.models import Count, Q
from django.utils import timezone
from apps.reports.models import Report
from apps.tasks.models import Task
from apps.assets.models import Asset
from apps.notifications.models import Notification
from django.contrib.auth import get_user_model
from utils.responses import success_response
from utils.permissions import IsSystemAdmin, IsAdminOrDepartmentAdmin

User = get_user_model()

class DashboardSummaryView(APIView):
    permission_classes = [IsAdminOrDepartmentAdmin]
    
    def get(self, request):
        user = request.user
        dept = getattr(user, 'managed_department', None) or getattr(user, 'department', None)
        
        # Scope data for department admins vs system admins
        if user.is_superuser or user.role == 'SYSTEM_ADMIN' or not dept:
            r_count = Report.objects.count()
            t_count = Task.objects.count()
            a_count = Asset.objects.count()
            u_count = User.objects.count()
        else:
            # For a department admin, scope to their department where applicable
            r_count = Report.objects.count() # Reports are global until assigned, but could filter by tasks
            t_count = Task.objects.filter(department=dept).count()
            a_count = Asset.objects.filter(department=dept).count()
            u_count = User.objects.count()

        data = {
            "total_reports": r_count,
            "total_tasks": t_count,
            "total_assets": a_count,
            "total_users": u_count
        }
        return success_response(data=data, message="Dashboard summary retrieved.")

class ReportStatisticsView(APIView):
    permission_classes = [IsAdminOrDepartmentAdmin]
    
    def get(self, request):
        stats = Report.objects.values('status').annotate(count=Count('id'))
        return success_response(data=list(stats), message="Report statistics retrieved.")

class TaskStatisticsView(APIView):
    permission_classes = [IsAdminOrDepartmentAdmin]
    
    def get(self, request):
        user = request.user
        dept = getattr(user, 'managed_department', None) or getattr(user, 'department', None)
        qs = Task.objects.all()
        if not (user.is_superuser or user.role == 'SYSTEM_ADMIN') and dept:
            qs = qs.filter(department=dept)
            
        stats = qs.values('status').annotate(count=Count('id'))
        return success_response(data=list(stats), message="Task statistics retrieved.")

class AssetStatisticsView(APIView):
    permission_classes = [IsAdminOrDepartmentAdmin]
    
    def get(self, request):
        user = request.user
        dept = getattr(user, 'managed_department', None) or getattr(user, 'department', None)
        qs = Asset.objects.all()
        if not (user.is_superuser or user.role == 'SYSTEM_ADMIN') and dept:
            qs = qs.filter(department=dept)
            
        status_stats = qs.values('status').annotate(count=Count('id'))
        condition_stats = qs.values('condition').annotate(count=Count('id'))
        return success_response(data={"status": list(status_stats), "condition": list(condition_stats)}, message="Asset statistics retrieved.")

class PriorityStatisticsView(APIView):
    permission_classes = [IsAdminOrDepartmentAdmin]
    
    def get(self, request):
        stats = Report.objects.values('priority').annotate(count=Count('id'))
        return success_response(data=list(stats), message="Priority statistics retrieved.")

class RecentReportsView(APIView):
    permission_classes = [IsAdminOrDepartmentAdmin]
    
    def get(self, request):
        reports = Report.objects.order_by('-created_at')[:10]
        data = [{"id": str(r.id), "report_number": r.report_number, "title": r.title, "status": r.status, "created_at": r.created_at} for r in reports]
        return success_response(data=data, message="Recent reports retrieved.")

class RecentTasksView(APIView):
    permission_classes = [IsAdminOrDepartmentAdmin]
    
    def get(self, request):
        user = request.user
        dept = getattr(user, 'managed_department', None) or getattr(user, 'department', None)
        qs = Task.objects.all()
        if not (user.is_superuser or user.role == 'SYSTEM_ADMIN') and dept:
            qs = qs.filter(department=dept)
            
        tasks = qs.order_by('-created_at')[:10]
        data = [{"id": str(t.id), "task_number": t.task_number, "title": t.title, "status": t.status, "created_at": t.created_at} for t in tasks]
        return success_response(data=data, message="Recent tasks retrieved.")

class RecentNotificationsView(APIView):
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        notifications = Notification.objects.filter(user=request.user).order_by('-created_at')[:10]
        data = [{"id": str(n.id), "title": n.title, "message": n.message, "is_read": n.is_read, "created_at": n.created_at} for n in notifications]
        return success_response(data=data, message="Recent notifications retrieved.")

class OverdueTasksView(APIView):
    permission_classes = [IsAdminOrDepartmentAdmin]
    
    def get(self, request):
        now = timezone.now()
        user = request.user
        dept = getattr(user, 'managed_department', None) or getattr(user, 'department', None)
        qs = Task.objects.filter(current_deadline__lt=now).exclude(status__in=['COMPLETED_PENDING_VERIFICATION', 'VERIFIED', 'CANCELLED'])
        if not (user.is_superuser or user.role == 'SYSTEM_ADMIN') and dept:
            qs = qs.filter(department=dept)
            
        tasks = qs.order_by('-current_deadline')[:10]
        data = [{"id": str(t.id), "task_number": t.task_number, "title": t.title, "status": t.status, "current_deadline": t.current_deadline} for t in tasks]
        return success_response(data=data, message="Overdue tasks retrieved.")
