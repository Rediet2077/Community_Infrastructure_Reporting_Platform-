from django.contrib.gis.geos import Point
from rest_framework import serializers
from utils.enums import LocationSource
from .models import Location


class LocationSerializer(serializers.ModelSerializer):
    latitude = serializers.FloatField(read_only=True)
    longitude = serializers.FloatField(read_only=True)

    # Write-only input fields
    lat = serializers.FloatField(write_only=True, required=True)
    lng = serializers.FloatField(write_only=True, required=True)

    class Meta:
        model = Location
        fields = [
            'id', 'address', 'landmark', 'accuracy_meters',
            'source', 'latitude', 'longitude', 'lat', 'lng',
            'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'created_at', 'updated_at']

    def validate_source(self, value):
        valid = [s[0] for s in LocationSource.choices]
        if value.upper() not in valid:
            raise serializers.ValidationError(f"Invalid source. Choose from: {valid}")
        return value.upper()

    def create(self, validated_data):
        lat = validated_data.pop('lat')
        lng = validated_data.pop('lng')
        validated_data['geom'] = Point(lng, lat, srid=4326)
        return super().create(validated_data)

    def update(self, instance, validated_data):
        lat = validated_data.pop('lat', None)
        lng = validated_data.pop('lng', None)
        if lat is not None and lng is not None:
            validated_data['geom'] = Point(lng, lat, srid=4326)
        return super().update(instance, validated_data)
