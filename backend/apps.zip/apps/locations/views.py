from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import Location
from .serializers import LocationSerializer

class LocationViewSet(viewsets.ModelViewSet):
    """
    API ViewSet for locations. 
    Allows creation of new locations and reading existing ones.
    """
    queryset = Location.objects.all()
    serializer_class = LocationSerializer
    permission_classes = [IsAuthenticated]

    @action(detail=False, methods=['get'], url_path='nearby-assets')
    def nearby_assets(self, request):
        lat = request.query_params.get('lat')
        lng = request.query_params.get('lng')
        radius_m = int(request.query_params.get('radius_m', 500))
        
        if not lat or not lng:
            return Response({"error": "'lat' and 'lng' required."}, status=400)
            
        try:
            from django.contrib.gis.geos import Point
            from django.contrib.gis.measure import D
            from apps.assets.models import Asset
            from apps.assets.serializers import AssetSerializer
            from utils.responses import success_response
            
            user_point = Point(float(lng), float(lat), srid=4326)
            assets = Asset.objects.filter(
                location__geom__distance_lte=(user_point, D(m=radius_m))
            )[:50]
            
            return success_response(data=AssetSerializer(assets, many=True).data, message="Nearby assets retrieved.")
        except Exception as e:
            return Response({"error": str(e)}, status=400)

    @action(detail=False, methods=['get'], url_path='nearby-reports')
    def nearby_reports(self, request):
        lat = request.query_params.get('lat')
        lng = request.query_params.get('lng')
        radius_m = int(request.query_params.get('radius_m', 500))
        
        if not lat or not lng:
            return Response({"error": "'lat' and 'lng' required."}, status=400)
            
        try:
            from django.contrib.gis.geos import Point
            from django.contrib.gis.measure import D
            from apps.reports.models import Report
            from apps.reports.serializers import ReportSerializer
            from utils.responses import success_response
            
            user_point = Point(float(lng), float(lat), srid=4326)
            reports = Report.objects.filter(
                location__geom__distance_lte=(user_point, D(m=radius_m))
            ).order_by('-created_at')[:50]
            
            return success_response(data=ReportSerializer(reports, many=True).data, message="Nearby reports retrieved.")
        except Exception as e:
            return Response({"error": str(e)}, status=400)
