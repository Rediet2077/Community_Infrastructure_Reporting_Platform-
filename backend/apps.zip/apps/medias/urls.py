from django.urls import path
from .views import MediaListView, MediaPresignedUrlView, MediaConfirmView

urlpatterns = [
    path('', MediaListView.as_view(), name='media-list'),
    path('presigned-url/', MediaPresignedUrlView.as_view(), name='media-presigned-url'),
    path('confirm/', MediaConfirmView.as_view(), name='media-confirm'),
]
