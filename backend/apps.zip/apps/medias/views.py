import uuid
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from .models import Media
from .serializers import MediaSerializer
from .services import attach_evidence
from utils.responses import success_response

class MediaListView(APIView):
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        entity_type = request.query_params.get('entity_type')
        entity_id = request.query_params.get('entity_id')
        
        qs = Media.objects.all()
        if entity_type:
            qs = qs.filter(entity_type=entity_type)
        if entity_id:
            qs = qs.filter(entity_id=entity_id)
            
        return success_response(data=MediaSerializer(qs, many=True).data, message="Media retrieved.")

class MediaPresignedUrlView(APIView):
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        file_name = request.data.get('file_name', 'upload.jpg')
        file_type = request.data.get('file_type', 'image/jpeg')
        
        final_url = f"https://mock-storage.local/{uuid.uuid4()}-{file_name}"
        data = {
            "upload_url": f"https://mock-storage.local/upload?filename={file_name}",
            "file_url": final_url
        }
        return success_response(data=data, message="Presigned URL generated.")

class MediaConfirmView(APIView):
    permission_classes = [IsAuthenticated]
    
    def post(self, request):
        entity_type = request.data.get('entity_type')
        entity_id = request.data.get('entity_id')
        media_data = request.data.get('media_data', [])
        
        if not entity_type or not entity_id or not media_data:
            return Response({"error": "Missing required fields."}, status=400)
            
        media_records = attach_evidence(
            user=request.user,
            entity_type=entity_type,
            entity_id=entity_id,
            media_data=media_data
        )
        return success_response(data=MediaSerializer(media_records, many=True).data, message="Media attached successfully.")
