import uuid
from django.db import models
from django.conf import settings
from utils.enums import ReportPriority, ReportStatus

class Report(models.Model):

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    report_number = models.CharField(max_length=50, unique=True)
    title = models.CharField(max_length=255)
    description = models.TextField()
    
    # Foreign Keys
    citizen = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='reports')
    asset = models.ForeignKey('assets.Asset', on_delete=models.SET_NULL, null=True, blank=True, related_name='reports')
    category = models.ForeignKey('categories.Category', on_delete=models.PROTECT, related_name='reports')
    location = models.ForeignKey('locations.Location', on_delete=models.PROTECT, related_name='reports')
    
    priority = models.CharField(max_length=20, choices=ReportPriority.choices, default=ReportPriority.MEDIUM)
    status = models.CharField(max_length=30, choices=ReportStatus.choices, default=ReportStatus.SUBMITTED)
    
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.report_number} - {self.title}"