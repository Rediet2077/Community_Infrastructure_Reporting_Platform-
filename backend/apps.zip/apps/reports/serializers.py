from rest_framework import serializers
from apps.locations.models import Location
from .models import Report


class LocationInputSerializer(serializers.Serializer):
    """Validates incoming GPS coordinates for a report submission."""
    lat = serializers.FloatField(required=True)
    lng = serializers.FloatField(required=True)
    address = serializers.CharField(required=False, allow_blank=True, default='')
    landmark = serializers.CharField(required=False, allow_blank=True, default='')
    accuracy_meters = serializers.DecimalField(max_digits=10, decimal_places=2, required=False, allow_null=True)


class ReportSerializer(serializers.ModelSerializer):
    """Serializer for reading Report data (API responses)."""
    citizen_email = serializers.ReadOnlyField(source='citizen.email')
    category_name = serializers.ReadOnlyField(source='category.name')
    latitude = serializers.FloatField(source='location.latitude', read_only=True)
    longitude = serializers.FloatField(source='location.longitude', read_only=True)

    class Meta:
        model = Report
        fields = [
            'id', 'report_number', 'title', 'description',
            'citizen', 'citizen_email', 'asset', 'category', 'category_name',
            'location', 'latitude', 'longitude',
            'priority', 'status', 'created_at', 'updated_at',
        ]
        read_only_fields = ['id', 'report_number', 'citizen', 'status', 'created_at', 'updated_at']


class ReportSubmissionSerializer(serializers.Serializer):
    """Serializer for the report submission payload (write-only)."""
    title = serializers.CharField(max_length=255)
    description = serializers.CharField()
    category = serializers.UUIDField()
    asset = serializers.UUIDField(required=False, allow_null=True)
    priority = serializers.CharField(max_length=20, required=False, default='MEDIUM')
    location = LocationInputSerializer()

    def validate_category(self, value):
        from apps.categories.models import Category
        try:
            return Category.objects.get(id=value, is_active=True)
        except Category.DoesNotExist:
            raise serializers.ValidationError("Invalid or inactive category.")

    def validate_asset(self, value):
        if value is None:
            return None
        from apps.assets.models import Asset
        try:
            return Asset.objects.get(id=value)
        except Asset.DoesNotExist:
            raise serializers.ValidationError("Asset not found.")

    def validate_priority(self, value):
        from utils.enums import ReportPriority
        valid = [p[0] for p in ReportPriority.choices]
        if value.upper() not in valid:
            raise serializers.ValidationError(f"Invalid priority. Choose from: {valid}")
        return value.upper()