import logging
import httpx
from django.conf import settings

logger = logging.getLogger(__name__)

class AIServiceException(Exception):
    pass

def classify_image(image_file):
    """
    Calls the AI service to classify a report image.
    Returns the classification result dict or None if it fails.
    """
    url = f"{settings.AI_SERVICE_BASE_URL}/ai/classify-image/"
    timeout = getattr(settings, 'AI_SERVICE_TIMEOUT', 30)
    
    try:
        # httpx post with files
        with httpx.Client(timeout=timeout) as client:
            response = client.post(
                url,
                files={"file": image_file},
            )
            response.raise_for_status()
            return response.json()
    except httpx.RequestError as exc:
        logger.error(f"An error occurred while requesting {exc.request.url!r}.")
        return None
    except httpx.HTTPStatusError as exc:
        logger.error(f"Error response {exc.response.status_code} while requesting {exc.request.url!r}.")
        return None
    except Exception as e:
        logger.error(f"Unexpected error in classify_image: {e}")
        return None

def detect_duplicate(report_data):
    """
    Calls the AI service to detect if a report is a duplicate.
    report_data should match the AI API expected JSON.
    Returns the duplication result dict or None if it fails.
    """
    url = f"{settings.AI_SERVICE_BASE_URL}/ai/detect-duplicate/"
    timeout = getattr(settings, 'AI_SERVICE_TIMEOUT', 30)
    
    try:
        with httpx.Client(timeout=timeout) as client:
            response = client.post(
                url,
                json=report_data,
            )
            response.raise_for_status()
            return response.json()
    except httpx.RequestError as exc:
        logger.error(f"An error occurred while requesting {exc.request.url!r}.")
        return None
    except httpx.HTTPStatusError as exc:
        logger.error(f"Error response {exc.response.status_code} while requesting {exc.request.url!r}.")
        return None
    except Exception as e:
        logger.error(f"Unexpected error in detect_duplicate: {e}")
        return None
