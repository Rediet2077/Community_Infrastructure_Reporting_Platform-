import uuid
from django.utils import timezone
from django.db import transaction
from django.contrib.gis.geos import Point
from rest_framework.exceptions import ValidationError
from utils.enums import ReportStatus, LocationSource
from apps.locations.models import Location
from apps.reports.models import Report


def generate_report_number() -> str:
    """Generates a unique, human-readable report identifier."""
    return f"REP-{uuid.uuid4().hex[:8].upper()}"


@transaction.atomic
def submit_report(user, validated_data: dict, image_file=None) -> Report:
    """
    Core business logic for citizen report submission.
    1. Creates the Location record from lat/lng
    2. Creates the Report record
    3. Calls AI classify-image (non-blocking)
    4. Calls AI detect-duplicate against nearby reports (non-blocking)
    5. Returns report with AI insights
    """
    # 1. Extract and create location
    location_data = validated_data.pop('location')
    lat = float(location_data['lat'])
    lng = float(location_data['lng'])

    location = Location.objects.create(
        geom=Point(lng, lat, srid=4326),
        address=location_data.get('address', ''),
        landmark=location_data.get('landmark', ''),
        accuracy_meters=location_data.get('accuracy_meters'),
        source=LocationSource.GPS,
    )

    # 2. Create the report
    report = Report.objects.create(
        report_number=generate_report_number(),
        citizen=user,
        location=location,
        status=ReportStatus.SUBMITTED,
        **validated_data
    )

    # 3. AI Image Classification (non-blocking)
    ai_classification = None
    if image_file:
        try:
            from apps.reports.services.ai_service import classify_image
            ai_classification = classify_image(image_file)
        except Exception:
            pass

    # 4. AI Duplicate Detection against recent nearby reports
    ai_duplication = None
    try:
        from apps.reports.services.ai_service import detect_duplicate
        from django.contrib.gis.db.models.functions import Distance
        from django.contrib.gis.measure import D

        # Find the most recent similar report within 500m, excluding this one
        nearby = Report.objects.filter(
            location__geom__distance_lte=(location.geom, D(m=500)),
            category=report.category,
        ).exclude(id=report.id).order_by('-created_at').select_related('location').first()

        if nearby:
            report_data = {
                "report_id": str(report.id),
                "title": report.title,
                "description": report.description,
                "category": report.category.code,
                "latitude": lat,
                "longitude": lng,
                "existing_report_id": str(nearby.id),
                "existing_title": nearby.title,
                "existing_description": nearby.description,
                "existing_category": nearby.category.code,
                "existing_latitude": float(nearby.location.latitude),
                "existing_longitude": float(nearby.location.longitude),
            }
            ai_duplication = detect_duplicate(report_data)

            # Auto-merge if AI is highly confident
            if ai_duplication and ai_duplication.get('is_duplicate') and ai_duplication.get('similarity_score', 0) >= 0.90:
                report.status = ReportStatus.MERGED
                report.save(update_fields=['status', 'updated_at'])

    except Exception:
        pass

    return report, ai_classification, ai_duplication
