import logging
import threading
from apps.reports.models import Report
from apps.medias.models import Media
from utils.enums import ReportStatus

logger = logging.getLogger(__name__)


def run_ai_moderation_worker(report_id: str):
    """
    Background worker that calls the real AI service to:
    1. Classify attached images via POST /ai/classify-image/
    2. Detect duplicates via POST /ai/detect-duplicate/
    Then updates the report status based on the AI response.
    """
    try:
        report = Report.objects.select_related('category', 'location').get(id=report_id)
    except Report.DoesNotExist:
        logger.error(f"[AI Worker] Report {report_id} not found.")
        return

    from apps.reports.services.ai_service import classify_image, detect_duplicate

    # ── Step 1: Image Classification ──────────────────────────────────────
    media_items = Media.objects.filter(entity_type='REPORT', entity_id=report.id)
    image_files = [m for m in media_items if m.file_type == 'IMAGE']

    classification_result = None
    if image_files:
        # Classify the first image against the AI service
        first_image = image_files[0]
        try:
            import httpx
            from django.conf import settings

            url = first_image.file_url
            timeout = getattr(settings, 'AI_SERVICE_TIMEOUT', 30)

            # Download the image from storage URL and send to AI
            with httpx.Client(timeout=timeout) as client:
                img_response = client.get(url)
                img_response.raise_for_status()
                image_content = img_response.content

            # Send to AI classification endpoint
            classification_result = classify_image(
                ("image.jpg", image_content, "image/jpeg")
            )

            if classification_result:
                logger.info(
                    f"[AI Worker] Classification for {report.report_number}: "
                    f"category={classification_result.get('category')}, "
                    f"confidence={classification_result.get('confidence')}"
                )

                # If the AI is confident and the predicted category doesn't match,
                # log a warning but don't auto-reject — let admins review
                ai_confidence = classification_result.get('confidence', 0)
                ai_category = classification_result.get('category', '')

                if ai_confidence < 0.50:
                    # Low-confidence classification — flag for manual review
                    report.status = ReportStatus.UNDER_REVIEW
                    report.save(update_fields=['status', 'updated_at'])
                    logger.warning(
                        f"[AI Worker] Low confidence ({ai_confidence}) for "
                        f"{report.report_number}. Flagged for manual review."
                    )
        except Exception as e:
            logger.error(f"[AI Worker] Image classification failed for {report.report_number}: {e}")
    else:
        logger.info(f"[AI Worker] No images attached to report {report.report_number}, skipping classification.")

    # ── Step 2: Duplicate Detection ───────────────────────────────────────
    duplicate_result = None
    try:
        from django.contrib.gis.measure import D

        # Find the closest recent report in the same category within 500m
        nearby = Report.objects.filter(
            location__geom__distance_lte=(report.location.geom, D(m=500)),
            category=report.category,
        ).exclude(id=report.id).order_by('-created_at').select_related('location', 'category').first()

        if nearby:
            report_data = {
                "report_id": str(report.id),
                "title": report.title,
                "description": report.description,
                "category": report.category.code if report.category else "",
                "latitude": float(report.location.latitude),
                "longitude": float(report.location.longitude),
                "existing_report_id": str(nearby.id),
                "existing_title": nearby.title,
                "existing_description": nearby.description,
                "existing_category": nearby.category.code if nearby.category else "",
                "existing_latitude": float(nearby.location.latitude),
                "existing_longitude": float(nearby.location.longitude),
            }
            duplicate_result = detect_duplicate(report_data)

            if duplicate_result:
                logger.info(
                    f"[AI Worker] Duplicate check for {report.report_number}: "
                    f"is_duplicate={duplicate_result.get('is_duplicate')}, "
                    f"similarity={duplicate_result.get('similarity_score')}"
                )

                # Auto-merge if AI is highly confident it's a duplicate
                if (duplicate_result.get('is_duplicate')
                        and duplicate_result.get('similarity_score', 0) >= 0.90):
                    report.status = ReportStatus.MERGED
                    report.save(update_fields=['status', 'updated_at'])
                    logger.info(
                        f"[AI Worker] Report {report.report_number} auto-merged "
                        f"with {nearby.report_number} (similarity "
                        f"{duplicate_result.get('similarity_score')})"
                    )

                    # Notify the citizen
                    try:
                        from apps.notifications.services import create_notification
                        create_notification(
                            user=report.citizen,
                            title="Your report was identified as a duplicate",
                            message=(
                                f"Report '{report.title}' appears to be a duplicate of "
                                f"'{nearby.report_number}'. It has been automatically merged."
                            ),
                            notification_type="REPORT_MERGED",
                            entity_type="REPORT",
                            entity_id=nearby.id,
                        )
                    except Exception:
                        pass
        else:
            logger.info(f"[AI Worker] No nearby reports found for duplicate check on {report.report_number}.")

    except Exception as e:
        logger.error(f"[AI Worker] Duplicate detection failed for {report.report_number}: {e}")

    logger.info(f"[AI Worker] Finished processing report {report.report_number}.")


def trigger_ai_moderation_async(report_id: str):
    """Spawns a non-blocking daemon thread so the API returns immediately."""
    thread = threading.Thread(
        target=run_ai_moderation_worker,
        args=(report_id,),
        daemon=True,
    )
    thread.start()


# ---------------------------------------------------------------------------
# Celery Compatibility Layer
# ---------------------------------------------------------------------------
# If Celery is installed and configured, expose .delay() for queue-based execution.
# Otherwise, fall back to background threads.
try:
    from celery import shared_task

    @shared_task
    def process_report_ai_moderation(report_id: str):
        """Celery task wrapper around the AI moderation worker."""
        run_ai_moderation_worker(report_id)

except ImportError:
    class ThreadedTask:
        def __init__(self, func):
            self.func = func

        def __call__(self, *args, **kwargs):
            return self.func(*args, **kwargs)

        def delay(self, *args, **kwargs):
            thread = threading.Thread(target=self.func, args=args, kwargs=kwargs, daemon=True)
            thread.start()

    process_report_ai_moderation = ThreadedTask(run_ai_moderation_worker)