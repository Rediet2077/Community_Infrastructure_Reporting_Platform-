from django.urls import path
from . import views

app_name = 'reports'

urlpatterns = [
    path('submit/', views.ReportSubmissionView.as_view(), name='submit-report'),
    path('', views.ReportListView.as_view(), name='report-list'),
    path('nearby/', views.NearbyReportsView.as_view(), name='nearby-reports'),
    path('<uuid:id>/', views.ReportDetailView.as_view(), name='report-detail'),
    path('<uuid:id>/merge/', views.MergeReportsView.as_view(), name='merge-reports'),
    path('<uuid:id>/accept/', views.ReportAcceptView.as_view(), name='accept-report'),
    path('<uuid:id>/reject/', views.ReportRejectView.as_view(), name='reject-report'),
    path('<uuid:id>/timeline/', views.ReportTimelineView.as_view(), name='timeline-report'),
    path('<uuid:id>/collaborations/', views.ReportCollaborationCreateView.as_view(), name='report-collaborations'),
]