from rest_framework import generics, views, status, filters
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework.parsers import MultiPartParser, FormParser, JSONParser
from django_filters.rest_framework import DjangoFilterBackend
from utils.permissions import IsAdminOrDepartmentAdmin
from utils.responses import success_response

from .models import Report
from .serializers import ReportSerializer, ReportSubmissionSerializer
from .services.report_service import submit_report


class ReportSubmissionView(views.APIView):
    """
    POST /api/v1/reports/submit/
    Citizen submits an infrastructure report. Handles image upload,
    location creation, and triggers AI classification + duplicate detection.
    """
    permission_classes = [IsAuthenticated]
    parser_classes = [MultiPartParser, FormParser, JSONParser]

    def post(self, request, *args, **kwargs):
        serializer = ReportSubmissionSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)

        image_file = request.FILES.get('image')

        report, ai_classification, ai_duplication = submit_report(
            user=request.user,
            validated_data=serializer.validated_data,
            image_file=image_file,
        )

        return success_response(
            data={
                'report': ReportSerializer(report).data,
                'ai_insights': {
                    'classification': ai_classification,
                    'duplication': ai_duplication,
                }
            },
            message="Report submitted successfully.",
            status_code=status.HTTP_201_CREATED,
        )


class ReportListView(generics.ListAPIView):
    """
    GET /api/v1/reports/
    List reports. Citizens see their own, Admins/DeptAdmins see all.
    """
    serializer_class = ReportSerializer
    permission_classes = [IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['status', 'priority', 'category']
    search_fields = ['title', 'description', 'report_number']
    ordering_fields = ['created_at', 'priority', 'status']

    def get_queryset(self):
        user = self.request.user
        qs = Report.objects.select_related('citizen', 'category', 'location', 'asset')

        if user.is_staff or user.role in ['SYSTEM_ADMIN', 'DEPARTMENT_ADMIN']:
            return qs.order_by('-created_at')

        # Citizens only see their own reports
        return qs.filter(citizen=user).order_by('-created_at')


class ReportDetailView(generics.RetrieveUpdateAPIView):
    """
    GET/PATCH /api/v1/reports/<id>/
    Retrieve or update a report. Status transitions enforced by Admin/DeptAdmin.
    """
    serializer_class = ReportSerializer
    permission_classes = [IsAuthenticated]
    queryset = Report.objects.select_related('citizen', 'category', 'location', 'asset')
    lookup_field = 'id'

    def get_permissions(self):
        if self.request.method in ['PUT', 'PATCH']:
            return [IsAdminOrDepartmentAdmin()]
        return [IsAuthenticated()]


class NearbyReportsView(views.APIView):
    """
    GET /api/v1/reports/nearby/?lat=9.0192&lng=38.7525&radius_m=500
    Returns reports within a given radius of the provided coordinates.
    """
    permission_classes = [IsAuthenticated]

    def get(self, request, *args, **kwargs):
        lat = request.query_params.get('lat')
        lng = request.query_params.get('lng')
        radius_m = int(request.query_params.get('radius_m', 500))

        if not lat or not lng:
            return Response(
                {"error": "'lat' and 'lng' query parameters are required."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            from django.contrib.gis.geos import Point
            from django.contrib.gis.measure import D

            user_point = Point(float(lng), float(lat), srid=4326)
            nearby_reports = Report.objects.filter(
                location__geom__distance_lte=(user_point, D(m=radius_m))
            ).select_related('category', 'location').order_by('-created_at')[:50]

            serializer = ReportSerializer(nearby_reports, many=True)
            return success_response(
                data=serializer.data,
                message=f"Found {len(serializer.data)} reports within {radius_m}m.",
            )
        except Exception as e:
            return Response({"error": str(e)}, status=status.HTTP_400_BAD_REQUEST)


class MergeReportsView(views.APIView):
    """
    POST /api/v1/reports/<id>/merge/
    Admin manually merges a duplicate report (the one in the URL) into a primary one.
    Body: {"primary_report_id": "uuid"}
    """
    permission_classes = [IsAdminOrDepartmentAdmin]

    def post(self, request, id, *args, **kwargs):
        from utils.enums import ReportStatus

        primary_id = request.data.get('primary_report_id')
        duplicate_id = str(id)

        if not primary_id:
            return Response(
                {"error": "'primary_report_id' is required."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        if primary_id == duplicate_id:
            return Response(
                {"error": "Primary and duplicate reports cannot be the same."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            primary = Report.objects.get(id=primary_id)
            duplicate = Report.objects.get(id=duplicate_id)
        except Report.DoesNotExist:
            return Response({"error": "One or both reports not found."}, status=status.HTTP_404_NOT_FOUND)

        if duplicate.status == ReportStatus.MERGED:
            return Response({"error": "Report is already merged."}, status=status.HTTP_400_BAD_REQUEST)

        duplicate.status = ReportStatus.MERGED
        duplicate.save(update_fields=['status', 'updated_at'])

        try:
            from apps.notifications.services import create_notification
            create_notification(
                user=duplicate.citizen,
                title="Your report was merged",
                message=f"Report '{duplicate.title}' has been identified as a duplicate and merged with '{primary.report_number}'.",
                notification_type="REPORT_MERGED",
                entity_type="REPORT",
                entity_id=primary.id,
            )
        except Exception:
            pass

        return success_response(
            data=ReportSerializer(primary).data,
            message=f"Report {duplicate_id} merged into {primary_id}.",
        )

class ReportAcceptView(views.APIView):
    permission_classes = [IsAdminOrDepartmentAdmin]
    
    def post(self, request, id, *args, **kwargs):
        from utils.enums import ReportStatus
        try:
            report = Report.objects.get(id=id)
        except Report.DoesNotExist:
            return Response({"error": "Report not found."}, status=status.HTTP_404_NOT_FOUND)
            
        report.status = ReportStatus.ACCEPTED
        report.save(update_fields=['status', 'updated_at'])
        return success_response(message="Report accepted.")

class ReportRejectView(views.APIView):
    permission_classes = [IsAdminOrDepartmentAdmin]
    
    def post(self, request, id, *args, **kwargs):
        from utils.enums import ReportStatus
        try:
            report = Report.objects.get(id=id)
        except Report.DoesNotExist:
            return Response({"error": "Report not found."}, status=status.HTTP_404_NOT_FOUND)
            
        report.status = ReportStatus.REJECTED
        report.save(update_fields=['status', 'updated_at'])
        return success_response(message="Report rejected.")

class ReportTimelineView(views.APIView):
    permission_classes = [IsAuthenticated]
    
    def get(self, request, id, *args, **kwargs):
        from apps.audit.models import AuditLog
        from apps.audit.serializers import AuditLogSerializer
        
        try:
            report = Report.objects.get(id=id)
        except Report.DoesNotExist:
            return Response({"error": "Report not found."}, status=status.HTTP_404_NOT_FOUND)
            
        logs = AuditLog.objects.filter(entity_type='Report', entity_id=report.id).order_by('created_at')
        return success_response(data=AuditLogSerializer(logs, many=True).data, message="Report timeline retrieved.")

class ReportCollaborationCreateView(views.APIView):
    permission_classes = [IsAdminOrDepartmentAdmin]
    
    def post(self, request, id, *args, **kwargs):
        from apps.collaborations.services import create_collaboration_request
        from apps.collaborations.serializers import CollaborationSerializer
        
        try:
            report = Report.objects.get(id=id)
        except Report.DoesNotExist:
            return Response({"error": "Report not found."}, status=status.HTTP_404_NOT_FOUND)
            
        supporting_dept_id = request.data.get('supporting_department_id')
        reason = request.data.get('reason', '')
        
        if not supporting_dept_id or not reason:
            return Response({"error": "'supporting_department_id' and 'reason' are required."}, status=400)
            
        try:
            collab = create_collaboration_request(
                report_id=report.id,
                requested_by_user=request.user,
                supporting_dept_id=supporting_dept_id,
                reason=reason
            )
            return success_response(data=CollaborationSerializer(collab).data, message="Collaboration requested.")
        except Exception as e:
            return Response({"detail": str(e)}, status=400)
