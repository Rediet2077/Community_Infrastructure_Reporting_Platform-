from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import TaskViewSet, TaskExtensionViewSet

router = DefaultRouter()
router.register(r'task-extensions', TaskExtensionViewSet, basename='task-extension')
router.register(r'', TaskViewSet, basename='task')

urlpatterns = [
    path('', include(router.urls)),
]