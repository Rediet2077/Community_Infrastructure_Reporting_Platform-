from django.urls import path, include
from apps.assets.views import MapAssetView

urlpatterns = [
    # Auth, Users & Audit
    path('', include('apps.users.urls')),
    path('', include('apps.audit.urls')),
    
    # Core Domain Apps
    path('map/assets/', MapAssetView.as_view(), name='map-assets'),
    path('reports/', include('apps.reports.urls')),
    path('tasks/', include('apps.tasks.urls')),
    path('assets/', include('apps.assets.urls')),
    path('disputes/', include('apps.disputes.urls')),
    path('categories/', include('apps.categories.urls')),
    path('locations/', include('apps.locations.urls')),
    path('media/', include('apps.medias.urls')),
    path('dashboard/', include('apps.dashboard.urls')),
    
    # Apps that define their own root prefixes internally
    path('', include('apps.departments.urls')),
    path('', include('apps.collaborations.urls')),
    path('', include('apps.notifications.urls')),
]