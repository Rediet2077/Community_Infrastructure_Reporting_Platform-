from django.shortcuts import render
from rest_framework import views, status
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework import viewsets
from .serializers import AssetRegistrationSerializer, AssetSerializer, AssetTypeSerializer
from .models import Asset, AssetType
from .services import register_infrastructure_asset

class AssetRegistrationView(views.APIView):
    permission_classes = [IsAuthenticated]

    def post(self, request):
        serializer = AssetRegistrationSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        
        # Hand off to the service layer
        asset = register_infrastructure_asset(
            user=request.user, 
            validated_data=serializer.validated_data
        )
        
        return Response({
            "message": "Asset registered successfully.",
            "asset_id": str(asset.id),
            "asset_code": asset.asset_code
        }, status=status.HTTP_201_CREATED)

class AssetViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Asset.objects.all()
    serializer_class = AssetSerializer
    permission_classes = [IsAuthenticated]
    
    def get_queryset(self):
        queryset = super().get_queryset()
        department_id = self.request.query_params.get('department_id')
        if department_id:
            queryset = queryset.filter(department_id=department_id)
        
        search = self.request.query_params.get('search')
        if search:
            queryset = queryset.filter(name__icontains=search) | queryset.filter(asset_code__icontains=search)
        
        return queryset

class AssetTypeViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = AssetType.objects.all()
    serializer_class = AssetTypeSerializer
    permission_classes = [IsAuthenticated]

class MapAssetView(views.APIView):
    permission_classes = [AllowAny]
    
    def get(self, request):
        assets = Asset.objects.all()
        
        # Filter by department if provided
        department_id = request.query_params.get('department_id')
        if department_id:
            assets = assets.filter(department_id=department_id)
        
        data = []
        for asset in assets:
            # We skip heavy extra_data payload for map dots
            data.append({
                "id": str(asset.id),
                "asset_code": asset.asset_code,
                "latitude": asset.extra_data.get('latitude', 0.0) if asset.extra_data else 0.0,
                "longitude": asset.extra_data.get('longitude', 0.0) if asset.extra_data else 0.0,
            })
        return Response(data)