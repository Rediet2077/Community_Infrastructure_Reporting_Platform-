from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from utils.permissions import IsSystemAdmin
from django.db.models import Count, Q
from apps.reports.models import Report
from apps.reports.serializers import ReportSerializer


class DashboardStatsView(APIView):
    """
    Dashboard statistics endpoint for system admin overview
    """
    permission_classes = [IsSystemAdmin]
    
    def get(self, request):
        # Get count by status
        total_reports = Report.objects.filter(is_deleted_by_admin=False).count()
        pending_reports = Report.objects.filter(status='SUBMITTED', is_deleted_by_admin=False).count()
        in_progress_reports = Report.objects.filter(
            status__in=['ACCEPTED', 'IN_PROGRESS'], 
            is_deleted_by_admin=False
        ).count()
        resolved_reports = Report.objects.filter(status='RESOLVED', is_deleted_by_admin=False).count()
        critical_reports = Report.objects.filter(priority='CRITICAL', is_deleted_by_admin=False).count()
        
        # Get recent reports
        recent_reports = Report.objects.filter(
            is_deleted_by_admin=False
        ).select_related('citizen', 'category').order_by('-created_at')[:10]
        
        # Count by category
        reports_by_category = list(Report.objects.filter(
            is_deleted_by_admin=False
        ).values('category__name').annotate(count=Count('id')))
        
        # Count by status
        reports_by_status = list(Report.objects.filter(
            is_deleted_by_admin=False
        ).values('status').annotate(count=Count('id')))
        
        return Response({
            'total_reports': total_reports,
            'pending_reports': pending_reports,
            'in_progress_reports': in_progress_reports,
            'resolved_reports': resolved_reports,
            'critical_reports': critical_reports,
            'recent_reports': ReportSerializer(recent_reports, many=True, context={'request': request}).data,
            'reports_by_category': [
                {'category': item['category__name'], 'count': item['count']} 
                for item in reports_by_category
            ],
            'reports_by_status': [
                {'status': item['status'], 'count': item['count']} 
                for item in reports_by_status
            ],
        })
