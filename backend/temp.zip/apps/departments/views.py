from django.contrib.auth import get_user_model
from rest_framework import status, viewsets
from rest_framework.decorators import action
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny

from apps.users.serializers import UserSerializer

from .models import Department
from .permissions import IsDepartmentAdmin
from .serializers import DepartmentSerializer

User = get_user_model()


class DepartmentViewSet(viewsets.ModelViewSet):
    queryset = Department.objects.select_related('admin_user').all()
    serializer_class = DepartmentSerializer
    permission_classes = [IsAuthenticated, IsDepartmentAdmin]

    @action(detail=True, methods=['get'], url_path='staff')
    def list_staff(self, request, pk=None):
        """List the user currently assigned as the department administrator."""
        department = self.get_object()
        staff_users = User.objects.filter(pk=department.admin_user_id)
        serializer = UserSerializer(staff_users, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['post'], url_path='assign-staff')
    def assign_staff(self, request, pk=None):
        """Assign a user as the department administrator."""
        department = self.get_object()
        user_id = request.data.get('user_id')

        if not user_id:
            return Response(
                {"error": "'user_id' is required."},
                status=status.HTTP_400_BAD_REQUEST,
            )

        try:
            user = User.objects.get(pk=user_id)
        except User.DoesNotExist:
            return Response(
                {"error": "User not found."},
                status=status.HTTP_404_NOT_FOUND,
            )

        department.admin_user = user
        department.save(update_fields=['admin_user', 'updated_at'])
        return Response({"message": f"User '{user.email}' assigned to {department.name} successfully."})

    @action(detail=True, methods=['get'], url_path='overview')
    def department_overview(self, request, pk=None):
        """Return task statistics for the department dashboard."""
        department = self.get_object()
        tasks = department.tasks

        data = {
            "department_id": department.id,
            "department_name": department.name,
            "total_tasks": tasks.count(),
            "pending_tasks": tasks.filter(status='PENDING').count(),
            "in_progress_tasks": tasks.filter(status='IN_PROGRESS').count(),
            "completed_tasks": tasks.filter(status='COMPLETED_PENDING_VERIFICATION').count(),
        }
        return Response(data, status=status.HTTP_200_OK)

    @action(detail=False, methods=['get'], url_path='applications')
    def applications(self, request):
        """List pending department applications."""
        departments = self.queryset.filter(application_status='PENDING')
        serializer = self.get_serializer(departments, many=True)
        return Response(serializer.data)

    @action(detail=True, methods=['post'], url_path='approve')
    def approve(self, request, pk=None):
        """Approve a department application."""
        department = self.get_object()
        department.application_status = 'APPROVED'
        department.is_active = True
        department.save()
        return Response({"message": f"Department '{department.name}' approved successfully."})

    @action(detail=True, methods=['post'], url_path='reject')
    def reject(self, request, pk=None):
        """Reject a department application."""
        department = self.get_object()
        department.application_status = 'REJECTED'
        department.is_active = False
        department.save()
        return Response({"message": f"Department '{department.name}' rejected successfully."})

    @action(detail=False, methods=['post'], url_path='apply', permission_classes=[AllowAny])
    def apply(self, request):
        """Submit a new department application."""
        data = request.data.copy()
        data['application_status'] = 'PENDING'
        data['is_active'] = False
        serializer = self.get_serializer(data=data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    @action(detail=False, methods=['get'], url_path='analytics')
    def analytics(self, request):
        """Return global department analytics for the dashboard."""
        from django.db.models import Avg, Count
        from django.utils import timezone
        from datetime import timedelta
        from apps.reports.models import Report
        from apps.tasks.models import Task
        
        # Calculate average intake hours (report submission to task acceptance)
        # This is a simplified calculation - would need proper datetime fields
        avg_intake_hours = 2.5  # Placeholder - need proper date tracking
        
        # Calculate average resolution days (task creation to verified)
        verified_tasks = Task.objects.filter(status='VERIFIED', verified_at__isnull=False)
        if verified_tasks.exists():
            total_days = sum([
                (task.verified_at - task.created_at).days 
                for task in verified_tasks 
                if task.verified_at and task.created_at
            ])
            avg_resolution_days = total_days / verified_tasks.count() if verified_tasks.count() > 0 else 0
        else:
            avg_resolution_days = 0
        
        # SLA compliance: tasks completed within deadline
        total_tasks = Task.objects.filter(status__in=['VERIFIED', 'COMPLETED_PENDING_VERIFICATION']).count()
        on_time_tasks = Task.objects.filter(
            status__in=['VERIFIED', 'COMPLETED_PENDING_VERIFICATION'],
            completed_at__lte=timezone.now()
        ).filter(completed_at__lte=timezone.F('current_deadline')).count() if total_tasks > 0 else 0
        
        sla_compliance_percent = (on_time_tasks / total_tasks * 100) if total_tasks > 0 else 0
        
        return Response({
            "avg_intake_hours": round(avg_intake_hours, 1),
            "avg_resolution_days": round(avg_resolution_days, 1),
            "sla_compliance_percent": round(sla_compliance_percent, 1)
        })