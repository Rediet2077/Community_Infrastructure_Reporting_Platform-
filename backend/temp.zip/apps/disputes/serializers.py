from rest_framework import serializers
from django.contrib.auth import get_user_model
from .models import Dispute
# DisputeComment model not yet implemented - serializer disabled
# from .models import DisputeComment

User = get_user_model()


class DisputeUserSerializer(serializers.ModelSerializer):
    """Nested serializer for displaying submitter and reviewer info."""
    class Meta:
        model = User
        fields = ['id', 'email', 'first_name', 'last_name']


# DisputeCommentSerializer disabled until DisputeComment model is created
# class DisputeCommentSerializer(serializers.ModelSerializer):
#     """Serializer for dispute discussion comments and evidence notes."""
#     author_detail = DisputeUserSerializer(source='author', read_only=True)
#
#     class Meta:
#         model = DisputeComment
#         fields = ['id', 'dispute', 'author', 'author_detail', 'comment', 'created_at']
#         read_only_fields = ['id', 'author', 'created_at']


class DisputeSerializer(serializers.ModelSerializer):
    # Convenience read-only email fields
    submitted_by_email = serializers.ReadOnlyField(source='submitted_by.email', default=None)

    # Detailed user representations
    submitted_by_detail = DisputeUserSerializer(source='submitted_by', read_only=True)
    reviewed_by_detail = DisputeUserSerializer(source='reviewed_by', read_only=True)

    # Nested comment thread disabled until model is created
    # comments = DisputeCommentSerializer(many=True, read_only=True)

    class Meta:
        model = Dispute
        fields = [
            'id',
            'report',
            'submitted_by',
            'submitted_by_email',
            'submitted_by_detail',
            'reviewed_by',
            'reviewed_by_detail',
            'review_note',
            'reason',
            'status',
            # 'comments',  # Disabled
            'created_at',
            'reviewed_at',
        ]
        read_only_fields = [
            'id',
            'status',
            'reviewed_by',
            'review_note',
            'resolution_notes',
            'created_at',
            'updated_at',
            'reviewed_at',
        ]