from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated, AllowAny
from rest_framework import status


class NotificationListView(APIView):
    """
    Real notification list endpoint with department filtering
    """
    permission_classes = [IsAuthenticated]
    
    def get(self, request):
        from .models import Notification
        user = request.user
        
        # Start with user's notifications
        if user and not user.is_anonymous:
            qs = Notification.objects.filter(user=user)
        else:
            qs = Notification.objects.all()
        
        # Filter by department if provided
        department_id = request.query_params.get('department_id')
        if department_id:
            # Assuming notifications have a department field or can be filtered via user
            # For now, filter by user's managed department
            qs = qs.filter(user__managed_department_id=department_id)
        
        qs = qs.order_by('-created_at')
            
        data = [{
            'id': str(n.id),
            'title': n.title,
            'message': n.message,
            'is_read': n.is_read,
            'created_at': n.created_at.isoformat(),
        } for n in qs[:50]]
        
        unread_count = sum(1 for item in data if not item['is_read'])
        
        return Response({
            'success': True,
            'message': 'Notifications retrieved successfully',
            'data': data,
            'unread_count': unread_count,
            'count': len(data),
            'next': None,
            'previous': None,
        }, status=status.HTTP_200_OK)
