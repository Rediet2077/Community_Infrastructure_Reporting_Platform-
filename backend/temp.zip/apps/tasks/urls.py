from django.urls import path, include
from rest_framework.routers import DefaultRouter
from .views import TaskViewSet, ExtensionViewSet

router = DefaultRouter()
router.register(r'extensions', ExtensionViewSet, basename='extension')
router.register(r'', TaskViewSet, basename='task')

urlpatterns = [
    path('', include(router.urls)),
]